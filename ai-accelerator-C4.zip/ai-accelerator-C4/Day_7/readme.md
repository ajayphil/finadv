4th Collab: https://colab.research.google.com/drive/1zFt4qnmxxhShNCmuqcYf1GeY_j5sCDcO?usp=sharing
