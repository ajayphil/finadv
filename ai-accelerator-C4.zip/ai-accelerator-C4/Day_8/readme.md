https://colab.research.google.com/drive/1kIyccz4wes6Zr_AP70AgHvsYvWjyGmJ7?usp=sharing

https://colab.research.google.com/drive/1phAj7m8sVK3w59HahwmUvwysNmTgOKkg?usp=sharing

https://colab.research.google.com/drive/1qHhQdyHYaY-g5M-KEQUJyLzElC2k3obL?usp=sharing
