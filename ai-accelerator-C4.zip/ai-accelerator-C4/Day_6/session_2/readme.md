Here are the Notebooks
1. https://drive.google.com/file/d/1ItU1eU9dsI0RFKHkw_mnStPh1vY5dgFb/view?usp=sharing
2. https://drive.google.com/file/d/1fQlO0uaZE1LnHQajY2Cxgf-eOqqbpCB5/view?usp=sharing
3. https://drive.google.com/file/d/1i-aR04eVbwVoMWgGywRfXuPvmTgi_btZ/view?usp=sharing
