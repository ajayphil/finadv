Hugging face.ipynb: https://colab.research.google.com/drive/1nZHCdxftlWNkp62yquf6Z0s2dNpEUpWp?usp=sharing

Gradio_Essentials.ipynb: https://colab.research.google.com/drive/1tsnxtqYchYTKn96iFEHRhziiqASwfzKk?usp=sharing#scrollTo=af688503
